#ifndef RESOURCES_SCOREBOARD_BG_H_
#define RESOURCES_SCOREBOARD_BG_H_

#include <stdint.h>
#include "resource.h"

extern uint16_t scoreboard_bg[640 * 480];

#endif /* RESOURCES_SCOREBOARD_BG_H_ */
