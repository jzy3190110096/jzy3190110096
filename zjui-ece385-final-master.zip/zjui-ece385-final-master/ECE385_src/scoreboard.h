#ifndef SCOREBOARD_H_
#define SCOREBOARD_H_

void scoreboard_init();
void scoreboard_sendrequest();
void scoreboard_loop();

#endif /* SCOREBOARD_H_ */
