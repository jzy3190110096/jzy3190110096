# Contra Game Based on FPGA

## Intro

This is the final project of ECE385, developed by [Zhongbo Zhu (github.com)](https://github.com/zzb66666666x) and [Zhaohua Yang (github.com)](https://github.com/YangZhaohua123456). We developed this digital system based on Intel NIOS CPU and added other peripheral hardware drivers to make this dual player combat game. With the support of image, audio output, keyboard input, gamers can control the two characters to have a fight, each person have 5 points of HP, enjoy the game!

## System Architecture 

For detailed information, check out the FinalReport.pdf in the project folder. 

Hardware overview:

![image-20211107230001553](https://i.loli.net/2021/11/08/ClhXWjIaBUZQPJM.png)

Software overview:

<img src="https://i.loli.net/2021/11/08/6X1FItmfrE5i9AH.png" alt="image-20211107230906290" style="zoom:80%;" />

## Game Demo

![](Demo/gameplay.gif)
