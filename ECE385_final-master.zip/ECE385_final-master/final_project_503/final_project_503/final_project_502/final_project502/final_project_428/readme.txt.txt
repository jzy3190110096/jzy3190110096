The way the code would simply open the the lab project with quartus prime 
and directly upload the file after compilation would be fine.

After upload the software part to the fpga, then we could play the game.

Press the tank first to choose between "one-player-mode" or "two-players-mode" by pressing "w" or "s",
press "space" or "enter" to choose. For the one player mode, use "w", "s", "a", and "d" to move the tank and
use "c" to shoot. For the two players mode, the only difference would be that use "8", "u", "i", and "o" to move tank2
and use "h" to shoot the bomb.

T.I.P: We have some files related to audio, though they are not completely working, they do not affect our functionality